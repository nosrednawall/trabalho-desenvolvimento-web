

/**
1. Crie um script que ao informar a idade, diga se a pessoa é maior ou menor de idade.
 */

/**Nesse script é solicitado a idade do usuário e informado se ele maior ou menor de idade */
var idade = prompt("Qual é a sua idade ?");
if(idade < 18){
    alert("Você é menor de idade");
}else{
    alert("Você é maior de idade");
}