

/**
5.Apresente um script que mostre uma caixa de diálogo de boas vindas ao carregar a página.
 */

//primeiro captura os valores do usuário
var nome = prompt("Qual é o seu nome ?");
alert("Seja bem vindo "+nome);
document.write("Seja bem vindo "+nome);

